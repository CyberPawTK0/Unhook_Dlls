#pragma once

#ifndef UNHOOK_H
#define UNHOOK_H

#include <Windows.h>



BOOL InitializeNtSyscalls();
VOID UnhookAllLoadedDlls();



#endif // !UNHOOK_H
