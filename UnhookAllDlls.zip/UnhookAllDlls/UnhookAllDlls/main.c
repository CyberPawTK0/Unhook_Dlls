#include <Windows.h>
#include <stdio.h>
#include "UnhookAllDlls.h"



BOOL WINAPI CtrlHandler(DWORD CEvent)
{
	if (CEvent == CTRL_C_EVENT) {
		ExitProcess(0);
	}

    return FALSE;
}




int main() {

	if (InitializeNtSyscalls()) {
		UnhookAllLoadedDlls();
	}

	
	printf("[#] Press Ctrl+C To Quit ...\n");
	SetConsoleCtrlHandler((PHANDLER_ROUTINE)CtrlHandler, TRUE);
	while (1) {}
	return 0;
}

